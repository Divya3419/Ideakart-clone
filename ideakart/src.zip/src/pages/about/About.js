import React from 'react'
import styled from "styled-components";

const Ptag = styled.p`
margin-left:40px;
margin-right:40px;
font-weignt:20px;
font-size:20px;
margin-bottom:150px;
margin-top:30px;
`

function About() {
  return (
    <Ptag>Ideakart is a site that gives u an idea about the book you want to buy. We offer a huge collection of books in diverse categories.

    We have a user friendly search engine and a quick delivery system. With this we even provide best discounts on our books. You can write to us for any idea or any help you need.
    
    Ideakart is a site that gives u an idea and a platform for the book you want. We offer a huge collection of books in diverse categories.
    
    We have a user friendly search engine and a quick delivery system. With this we even provide best discounts on our books. You can write to us for any idea or any help you need.</ Ptag>
  )
}

export default About