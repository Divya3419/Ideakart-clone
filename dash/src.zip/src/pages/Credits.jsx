import React from 'react'
import { Credit } from '../components/Styled'

const Credits = () => {
  return (
    
      <Credit>
      <h1>Credits</h1>
      <p>The amount credited to your account will be shown here!
<br/>
You can update your account Info</p>
</Credit>
    
  )
}

export default Credits